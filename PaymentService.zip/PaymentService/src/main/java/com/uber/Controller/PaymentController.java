package com.uber.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.uber.Entity.BankAccount;
import com.uber.Entity.RequestPayment;
import com.uber.Service.PaymentService;

@RestController
@RequestMapping("/paymentApi")
public class PaymentController {

	@Autowired
	private PaymentService paymentService;

	@GetMapping("/")
	public ResponseEntity<?> descCourse() {
		return new ResponseEntity<>("Bank Api Working", HttpStatus.OK);
	}

	@PostMapping("/createUserAccout")
	public ResponseEntity<?> createUserAccout(@RequestBody BankAccount account) {
		paymentService.createUserAccout(account);

		return new ResponseEntity<BankAccount>(account, HttpStatus.CREATED);
	}

	@PostMapping("/paymentViaUpi")
	public ResponseEntity<?> paymentViaUpi(@RequestBody RequestPayment rqPayment) {
		boolean b = paymentService.paymentViaUpi(rqPayment);
		return ResponseEntity.status(HttpStatus.OK).body(b);
	}

	@PostMapping("/paymentViaAccNu")
	public ResponseEntity<?> paymentViaAccNu(@RequestBody RequestPayment rqPayment) {
		boolean b = paymentService.paymentViaAccNu(rqPayment);
		return ResponseEntity.status(HttpStatus.OK).body(b);
	}

}

package com.uber.Service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.uber.Entity.BankAccount;
import com.uber.Entity.RequestPayment;
import com.uber.Exception.PaymentException;
import com.uber.Repository.PaymentRepository;


@Service
public class PaymentServiceImpl implements PaymentService{
	@Autowired
	private PaymentRepository paymentRepository;
	@Override
	public void createUserAccout(BankAccount user) {
	    paymentRepository.save(user);
	}
 
	@Override
	public  boolean withdraAmmount(BankAccount bk ,double ammount) {
		if(bk.getBalance()<ammount) throw new PaymentException("Insufficient Ammount in Acc");
		bk.setBalance(bk.getBalance() - ammount);
		if( paymentRepository.save(bk) != null)
			return true;
		else return false;
	}

	@Override
	public boolean paymentViaUpi(RequestPayment rqdetails) {
		// TODO Auto-generated method stub
		BankAccount bankUser = paymentRepository.findByUpiId(rqdetails.getUpiId()).orElseThrow(() -> new PaymentException("Check The Account No"));
		if(withdraAmmount(bankUser,rqdetails.getWithdrawAmount())) {
			return true;
			
		}
		return false;
	}

	@Override
	public boolean paymentViaAccNu(RequestPayment rqdetails) {
		// TODO Auto-generated method stub
		BankAccount bankUser = paymentRepository.findById(rqdetails.getAccountNumber()).orElseThrow(() -> new PaymentException("Check The Account No"));
		if(withdraAmmount(bankUser, rqdetails.getWithdrawAmount())) {
			return true;
		}
		return false;
	}
	

	} 
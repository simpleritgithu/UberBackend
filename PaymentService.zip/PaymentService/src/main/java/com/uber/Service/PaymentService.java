package com.uber.Service;

import com.uber.Entity.BankAccount;
import com.uber.Entity.RequestPayment;

public interface PaymentService {
	void createUserAccout(BankAccount user);

	boolean withdraAmmount(BankAccount bk, double ammount);

	boolean paymentViaUpi(RequestPayment rqdetails);

	boolean paymentViaAccNu(RequestPayment rqdetails);

}
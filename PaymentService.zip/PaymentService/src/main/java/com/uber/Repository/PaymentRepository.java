package com.uber.Repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.uber.Entity.BankAccount;

@Repository
public interface PaymentRepository extends JpaRepository<BankAccount, Integer> {
	Optional<BankAccount> findByUpiId(String upiId);
}

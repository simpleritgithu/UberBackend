package com.uber.Entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


@Data
@NoArgsConstructor
@AllArgsConstructor
public class RequestPayment {
	private int accountNumber;
	private double withdrawAmount; // Corrected field name
	private String upiId;
}

package com.uber.Entity;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
@Table(name = "payment")
public class BankAccount {
	@Id
	private int accountNumber;
	private String accountHolderName; // Corrected field name for better readability
	private double balance;
	private String upiId;
}

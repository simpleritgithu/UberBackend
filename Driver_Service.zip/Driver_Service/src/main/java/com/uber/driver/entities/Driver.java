package com.uber.driver.entities;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;
 
@Entity

@Setter
@Getter
public class Driver {
 
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
 
    private String drivername;
    private String vehiclename;
    private String vehicletype;
    private String vehiclenumber;
    private DriverStatus status;  // ACTIVE, INACTIVE, or BUSY
 
    // Enum to represent driver status
    public enum DriverStatus {
        ACTIVE, INACTIVE, BUSY
    }
}
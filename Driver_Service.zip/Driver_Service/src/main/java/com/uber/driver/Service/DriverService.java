package com.uber.driver.Service;

import java.util.List;


import java.util.Optional;

import org.apache.catalina.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.uber.driver.Exception.DriverNotFoundException;
import com.uber.driver.Repository.DriverRepository;
import com.uber.driver.entities.Driver;


 
@Service
public class DriverService {
	@Autowired
    private DriverRepository driverRepository;
 
	
	
	public Driver add(Driver driver) {
		// TODO Auto-generated method stub
		return driverRepository.save(driver);
	}
 
	public List<Driver> getAllDrivers() {
		// TODO Auto-generated method stub
		return driverRepository.findAll();
	}
	// Update driver details by ID
    public Driver updateDriver(Long id, Driver updatedDriver) {
        Optional<Driver> existingDriver = driverRepository.findById(id);
        if (existingDriver.isPresent()) {
            Driver driver = existingDriver.get();
            driver.setDrivername(updatedDriver.getDrivername());
            driver.setVehiclename(updatedDriver.getVehiclename()); // Corrected this line
            driver.setVehicletype(updatedDriver.getVehicletype());
            driver.setVehiclenumber(updatedDriver.getVehiclenumber());
            return driverRepository.save(driver);
        }
        return null;
    }
    // Get vehicles by type
    public List<Driver> getVehiclesByType(String vehicletype) {
        return driverRepository.findByVehicletype(vehicletype);
    }
 
    // Get driver name by vehicle number
    public Optional<Driver> getDriverByVehicleNumber(String vehiclenumber) {
        return driverRepository.findByVehiclenumber(vehiclenumber);
    }
    public List<Driver> getAvailableDrivers() {
        // Find all drivers with status ACTIVE
        return driverRepository.findByStatus(Driver.DriverStatus.ACTIVE);
    }

    public boolean deleteDriver(Long id) {
        Optional<Driver> driver = driverRepository.findById(id);
        if (driver.isPresent()) {
            driverRepository.delete(driver.get());
            return true;
        }
        return false;
    }

	public List<Driver> getDriverById(Long id) {
		// TODO Auto-generated method stub
		return (List<Driver>) driverRepository.findById(id).orElseThrow(() -> new DriverNotFoundException("Driver not found with id: " + id));
	}
	}

 

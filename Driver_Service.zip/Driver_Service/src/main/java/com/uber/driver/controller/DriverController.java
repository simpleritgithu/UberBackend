package com.uber.driver.controller;

import java.util.List;

import java.util.Optional;
 
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.uber.driver.Service.DriverService;
import com.uber.driver.entities.Driver;

@RequestMapping("/driver")
@RestController
public class DriverController {
 
	@Autowired
	DriverService driverService;
	
	@PostMapping("/register")
    public ResponseEntity<Driver> registerUser(@RequestBody Driver driver) {
        Driver createdDriver = driverService.add(driver);
        return new ResponseEntity<>(createdDriver, HttpStatus.CREATED);
    }
 
    
    @GetMapping("/getall")
    public ResponseEntity<List<Driver>> getAllUsers() {
        List<Driver> driver = driverService.getAllDrivers();
        return new ResponseEntity<>(driver, HttpStatus.OK);
    }
    
    @GetMapping("/getdriver/{id}")
    public ResponseEntity<List<Driver>> getDriver(@PathVariable Long id) {
        List<Driver> driver = driverService.getDriverById(id);
        return new ResponseEntity<>(driver, HttpStatus.OK);
    }
   
    

    @GetMapping("/vtype/{vehicletype}")
    public ResponseEntity<List<Driver>> getVehiclesByType(@PathVariable String vehicletype) {
        List<Driver> drivers = driverService.getVehiclesByType(vehicletype);
        return new ResponseEntity<>(drivers, HttpStatus.OK);
    }
 
    // Get driver name by vehicle number
    @GetMapping("/vnum/{vehiclenumber}")
    public ResponseEntity<String> getDriverByVehicleNumber(@PathVariable String vehiclenumber) {
        Optional<Driver> driver = driverService.getDriverByVehicleNumber(vehiclenumber);
        if (driver.isPresent()) {
            return new ResponseEntity<>(driver.get().getDrivername(), HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }
// Update driver details by ID
    @PutMapping("update/{id}")
    public ResponseEntity<Driver> updateDriver(@PathVariable Long id, @RequestBody Driver updatedDriver) {
        Driver driver = driverService.updateDriver(id, updatedDriver);
        if (driver != null) {
            return new ResponseEntity<>(driver, HttpStatus.OK);
        }
        return new ResponseEntity<>(HttpStatus.NOT_FOUND);
    }
 
    // Delete driver by ID
    @DeleteMapping("delete/{id}")
    public ResponseEntity<Void> deleteDriver(@PathVariable Long id) {
        boolean isDeleted = driverService.deleteDriver(id);
        if (isDeleted) {
            return new ResponseEntity<>(HttpStatus.NO_CONTENT);
        }
        return new ResponseEntity<>(HttpStatus.NOT_FOUND);
    }
}

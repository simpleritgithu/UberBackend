package com.uber.Service;

import com.uber.dto.JwtAuthenticationResponse;
import com.uber.dto.SignUpRequest;
import com.uber.dto.SigninRequest;
import com.uber.entities.User;

public interface AuthenticationService {

	User signup(SignUpRequest signUpRequest);

	JwtAuthenticationResponse signin(SigninRequest signinRequest);
}

package com.uber.Service.ServiceImpl;

import java.util.HashMap;

import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.uber.Repository.UserRepository;
import com.uber.Service.AuthenticationService;
import com.uber.Service.JwtService;
import com.uber.dto.JwtAuthenticationResponse;
import com.uber.dto.SignUpRequest;
import com.uber.dto.SigninRequest;
import com.uber.entities.Role;
import com.uber.entities.User;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class AuthenticationServiceImpl implements AuthenticationService {

	private final UserRepository userRepository;

	private final PasswordEncoder passwordEncoder;

	private final AuthenticationManager authenticationManager;

	private final JwtService jwtService;

	public User signup(SignUpRequest signUpRequest) {
		User user = new User();

		user.setEmail(signUpRequest.getEmail());
		user.setFirstName(signUpRequest.getFirstName());
		user.setLastName(signUpRequest.getLastName());
		user.setRole(Role.USER);
		user.setPassword(passwordEncoder.encode(signUpRequest.getPassword()));

		return userRepository.save(user);
	}

	public JwtAuthenticationResponse signin(SigninRequest signinRequest) {
		authenticationManager.authenticate(
				new UsernamePasswordAuthenticationToken(signinRequest.getEmail(), signinRequest.getPassword()));

		var user = userRepository.findByEmail(signinRequest.getEmail())
				.orElseThrow(() -> new IllegalArgumentException("Invalid email or password"));
		var jwt = jwtService.generateToken(user);
		var refresh = jwtService.generateRefreshToken(new HashMap<>(), user);

		JwtAuthenticationResponse jwtAuthenticationResponse = new JwtAuthenticationResponse();
		jwtAuthenticationResponse.setToken(jwt);
		jwtAuthenticationResponse.setRefreshToken(refresh);

		return jwtAuthenticationResponse;
	}
}

package com.uber.entities;

public enum Role {

	USER, ADMIN
}

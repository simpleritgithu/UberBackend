package com.uber.dto;

import lombok.Data;

@Data
public class SignUpRequest {

	public String firstName;
	
	public String lastName;
	
	public String email;
	
	public String password;

}

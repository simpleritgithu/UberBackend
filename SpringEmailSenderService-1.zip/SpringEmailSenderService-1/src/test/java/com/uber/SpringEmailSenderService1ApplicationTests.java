package com.uber;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringEmailSenderService1ApplicationTests {

	@Test
	void contextLoads() {
	}

}

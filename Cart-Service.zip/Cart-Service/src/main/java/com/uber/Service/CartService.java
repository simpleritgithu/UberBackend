package com.uber.Service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.uber.Dto.Driver;
import com.uber.Dto.Ride;
import com.uber.Entity.Cart;
import com.uber.Entity.CartItem;
import com.uber.Repository.CartItemsRepository;
import com.uber.Repository.CartRepository;

import java.util.ArrayList;
import java.util.List;

@Service
public class CartService {

    @Autowired
    private CartRepository cartRepository;

    @Autowired
    private CartItemsRepository cartItemsRepository;

    @Autowired
    private RideClient rideClient;

    @Autowired
    private DriverClient driverClient;

    public Cart addToCart(Long userId, Long rideId, Long driverId) {
        // Fetch ride and driver details using Feign clients
        Ride ride = rideClient.getRideById(rideId);
        Driver driver = driverClient.getDriverById(driverId);

        if (ride != null && driver != null) {
            // Calculate fare (for simplicity, use the ride fare)
            double fare = ride.getFare();

            // Create CartItem
            CartItem cartItem = new CartItem();
            cartItem.setRideId(rideId);
            cartItem.setDriverId(driverId);
            cartItem.setFare(fare);

            // Create Cart if not exist
            Cart cart = cartRepository.findByUserId(userId);
            if (cart == null) {
                cart = new Cart();
                cart.setUserId(userId);
                cart.setTotalAmount(0);
            }

            // Add CartItem to Cart
            cart.getCartItems().add(cartItem);
            cart.setTotalAmount(cart.getTotalAmount() + fare);

            // Save Cart and CartItem
            cartRepository.save(cart);
            cartItemsRepository.save(cartItem);

            return cart;
        }
        throw new RuntimeException("Ride or Driver not found");
    }

    public Cart getCart(Long userId) {
        return cartRepository.findByUserId(userId);
    }

    public void removeCartItem(Long cartId, Long itemId) {
        Cart cart = cartRepository.findById(cartId).orElseThrow();
        CartItem item = cart.getCartItems().stream()
                .filter(cartItem -> cartItem.getId().equals(itemId))
                .findFirst()
                .orElseThrow();
        cart.getCartItems().remove(item);
        cart.setTotalAmount(cart.getTotalAmount() - item.getFare());
        cartRepository.save(cart);
    }
}

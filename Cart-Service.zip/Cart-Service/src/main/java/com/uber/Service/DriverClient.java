package com.uber.Service;

import org.springframework.cloud.openfeign.FeignClient;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.uber.Dto.Driver;

@FeignClient(name = "driver-service", url = "http://localhost:8081")  // URL of Driver Service
public interface DriverClient {

    // Get driver details by ID
    @GetMapping("/driver/get/{id}")
    Driver getDriverById(@PathVariable("id") Long id);
    
    // Add any other necessary methods to communicate with Driver Service, e.g., get all drivers, by vehicle type etc.
}
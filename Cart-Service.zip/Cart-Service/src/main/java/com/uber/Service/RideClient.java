package com.uber.Service;


import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.uber.Dto.Ride;

@FeignClient(name = "ride-service", url = "http://localhost:8082")  // URL of Ride Service
public interface RideClient {

    // Get ride details by ID
    @GetMapping("/rides/getride/{id}")
    Ride getRideById(@PathVariable("id") Long id);
}
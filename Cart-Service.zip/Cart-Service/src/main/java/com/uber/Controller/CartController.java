package com.uber.Controller;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.uber.Dto.Driver;
import com.uber.Entity.Cart;
import com.uber.Service.CartService;
import com.uber.Service.DriverClient;

@RestController
@RequestMapping("/cart")
public class CartController {

    @Autowired
    private CartService cartService;
    
    @Autowired
    private DriverClient driverClient;

    @PostMapping("/add")
    public ResponseEntity<Cart> addToCart(@RequestParam Long userId, @RequestParam Long rideId, @RequestParam Long driverId) {
        Cart cart = cartService.addToCart(userId, rideId, driverId);
        return ResponseEntity.ok(cart);
    }

    @GetMapping("/get/{userId}")
    public ResponseEntity<Cart> getCart(@PathVariable Long userId) {
        Cart cart = cartService.getCart(userId);
        return ResponseEntity.ok(cart);
    }

    @DeleteMapping("/remove/{cartId}/{itemId}")
    public ResponseEntity<Void> removeFromCart(@PathVariable Long cartId, @PathVariable Long itemId) {
        cartService.removeCartItem(cartId, itemId);
        return ResponseEntity.noContent().build();
    }
    
    @GetMapping("/driver/{id}")
    public Driver getDriver(@PathVariable Long id)
    {
    	return driverClient.getDriverById(id);
    }
}















//
//import java.util.List;
//import java.util.Map;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.http.ResponseEntity;
//import org.springframework.web.bind.annotation.DeleteMapping;
//import org.springframework.web.bind.annotation.GetMapping;
//import org.springframework.web.bind.annotation.PathVariable;
//import org.springframework.web.bind.annotation.PostMapping;
//import org.springframework.web.bind.annotation.RequestMapping;
//import org.springframework.web.bind.annotation.RestController;
////
////import com.example.demo.entity.Cart;
////import com.example.demo.entity.CartItem;
////import com.example.demo.service.CartService;
//
//import com.uber.Entity.Cart;
//import com.uber.Service.CartService;
//
//@RestController
//@RequestMapping("/cart")
//public class CartController {
//	
//    private final CartService cartService;
//    @Autowired
//    public CartController(CartService cartService) {
//        this.cartService = cartService;
//    }
//
//    @PostMapping("/add/ride/{cartId}/{rideId}")
//    public ResponseEntity<String> addRideToCart(@PathVariable Long cartId, @PathVariable Long rideId) {
//        cartService.addRideToCart(cartId, rideId);
//        return ResponseEntity.ok("Ride added to cart.");
//    }
//
//    @PostMapping("/add/food/{cartId}/{foodId}")
//    public ResponseEntity<String> addFoodToCart(@PathVariable Long cartId, @PathVariable Long foodId) {
//        cartService.addFoodToCart(cartId, foodId);
//        return ResponseEntity.ok("Food added to cart.");
//    }
//
//    @DeleteMapping("/remove/{cartId}/{itemId}")
//    public ResponseEntity<String> removeItemFromCart(@PathVariable Long cartId, @PathVariable Long itemId) {
//        cartService.removeItemFromCart(cartId, itemId);
//        return ResponseEntity.ok("Item removed from cart.");
//    }
//
//    @GetMapping("/items/{cartId}")
//    public ResponseEntity<Cart> getCartItems(@PathVariable Long cartId) {
//        //List<CartItem> items = cartService.getCartItems(cartId);
//    	Cart items=cartService.getCartItems(cartId);
//        return ResponseEntity.ok(items);
//    }
//    
////    @GetMapping("/cartdata/{cartId}")
////    public Map<List<CartItem>, Double> getCart(@PathVariable Long cartId) {
////        return cartService.getCart(cartId);
////    }
//}

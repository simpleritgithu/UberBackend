package com.uber.ride.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.uber.ride.entities.Ride;
import com.uber.ride.service.RideService;

import java.util.List;

@RestController
@RequestMapping("/rides")
public class RideController {
    @Autowired
    private RideService rideService;

    @PostMapping("/create")
    public ResponseEntity<Ride> createRide(@RequestBody Ride ride) {
        Ride createdRide = rideService.createRide(ride);
        return ResponseEntity.ok(createdRide);
    }

    @GetMapping("getride/{id}")
    public ResponseEntity<Ride> getRide(@PathVariable Long id) {
        Ride ride = rideService.getRideById(id);
        return ResponseEntity.ok(ride);
    }

    @GetMapping("/getuser/{userId}")
    public ResponseEntity<List<Ride>> getRidesByUser(@PathVariable Long userId) {
        List<Ride> rides = rideService.getRidesByUserId(userId);
        return ResponseEntity.ok(rides);
    }

    @DeleteMapping("delete/{id}")
    public ResponseEntity<Void> deleteRide(@PathVariable Long id) {
        rideService.deleteRide(id);
        return ResponseEntity.noContent().build();
    }
}


package com.uber.ride.service;

import java.sql.Driver;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.uber.ride.entities.Ride;
import com.uber.ride.exception.RideNotFoundException;

import com.uber.ride.repository.RideRepository;

@Service
public class RideService {
	@Autowired
	private RideRepository rideRepository;
	

	public Ride createRide(Ride ride) {
		return rideRepository.save(ride);
	}


	public List<Ride> getRidesByUserId(Long userId) {
		return rideRepository.findByUserId(userId);
	}

	public Ride getRideById(Long id) {
		return rideRepository.findById(id).orElseThrow(() -> new RideNotFoundException("Ride not found with id: " + id));
	}

	public void deleteRide(Long id) {
		rideRepository.deleteById(id);
	}
}

package com.uber.Dto;

import lombok.Data;

@Data
public class BookingResponseDto {

	private Long bookingId;
	private Long userId;
	private Long rideId;
	private String vehicleNumber;
	private String status;
}

package com.uber.Dto;



import lombok.Data;

@Data
public class DriverDto {
	private Long id;
	 
    private String drivername;
    private String vehiclename;
    private String vehicletype;
    private String vehiclenumber;
   // private DriverStatus status; 
}

package com.uber.Dto;

import lombok.Data;

@Data
public class BookingRequestDto {

	private Long userId;
    private Long rideId;
    private String vehicleNumber;
    private String pickupLocation;
    private String dropoffLocation;
}

package com.uber.Dto;

import java.time.LocalDateTime;

import lombok.Data;

@Data
public class RideDto {
	private Long id;

	private Long userId;
	private Long driverId;
	private String pickupLocation;
	private String dropoffLocation;
	private LocalDateTime startTime;
	private LocalDateTime endTime;
	private double fare;

}

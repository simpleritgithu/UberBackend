package com.uber.Client;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.uber.Dto.RideDto;

@FeignClient(name = "RideService" , url="http://localhost:8087")
public interface RideClient {

//	@GetMapping("/ride/getRideById/{rideId}")
//	public RideDto getRideById(@PathVariable("rideId") Long rideId);
	
	@GetMapping("rides/getride/{id}")
	public RideDto getRide(@PathVariable("id") long id) ;
}

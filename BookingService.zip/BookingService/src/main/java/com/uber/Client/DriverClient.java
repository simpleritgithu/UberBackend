package com.uber.Client;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.uber.Dto.DriverDto;
import com.uber.Dto.RideDto;

@FeignClient(name = "driver", url = "http://localhost:8081")
public interface DriverClient {

//    @GetMapping("/driver/vnum/{vehiclenumber}")
//    public DriverDto getDriverByVehicleNumber(@PathVariable("vehiclenumber") String vehiclenumber);

	@GetMapping("driver/getdriver/{id}")
	public DriverDto getDriverById(@PathVariable("id") long id);
}

package com.uber.Client;

//import org.springframework.cloud.openfeign.FeignClient;
//import org.springframework.web.bind.annotation.GetMapping;
//import org.springframework.web.bind.annotation.PathVariable;
//
//import com.uber.Dto.UserDto;
//
//@FeignClient(name = "user-service")
//public interface UserClient {
//
//	@GetMapping("/users/getUserById/{id}")
//	public UserDto getUserById(@PathVariable("id") Long id);
//}

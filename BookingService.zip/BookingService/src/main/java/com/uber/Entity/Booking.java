package com.uber.Entity;

import jakarta.persistence.*;
import lombok.Data;

@Entity
@Data
public class Booking {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	
	private Long userId;
	private Long rideId;
	private String vehicleNumber;
	private String status;
}
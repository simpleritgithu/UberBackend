package com.uber.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.uber.Dto.BookingRequestDto;
import com.uber.Dto.BookingResponseDto;
import com.uber.Service.BookingService;

@RestController
@RequestMapping("/booking")
public class BookingController {

	@Autowired
	private BookingService bookingService;

	@PostMapping("/create")
	public ResponseEntity<String> createBooking(@RequestBody BookingRequestDto bookingRequestDto) {
		BookingResponseDto responseDto = bookingService.createBooking(bookingRequestDto);
		return new ResponseEntity<String>("Booking Successfully ", HttpStatus.CREATED);
	}
}

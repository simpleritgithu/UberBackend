package com.uber.Service;

import org.springframework.beans.factory.annotation.Autowired;

//import org.springframework.beans.factory.annotation.Autowired(required=true)

import org.springframework.stereotype.Service;

import com.uber.Client.DriverClient;
import com.uber.Client.RideClient;

import com.uber.Dto.BookingRequestDto;
import com.uber.Dto.BookingResponseDto;
import com.uber.Dto.DriverDto;
import com.uber.Dto.RideDto;

import com.uber.Entity.Booking;
import com.uber.Repository.BookingRepository;

@Service
public class BookingService {

	@Autowired
	private BookingRepository bookingRepository;

	@Autowired
	private DriverClient driverClient;

	@Autowired
	private RideClient rideClient;

	//@Autowired
	//private UserClient userClient;

	public BookingResponseDto createBooking(BookingRequestDto request) {
		// Fetch driver details
		//DriverDto driver = driverClient.getDriverByVehicleNumber(request.getVehicleNumber());

		// Fetch ride details
		RideDto ride = rideClient.getRide(request.getRideId());

		// Fetch user details
		//UserDto user = userClient.getUserById(request.getUserId());

		// Create booking record
		Booking booking = new Booking();
		booking.setUserId(request.getUserId());
		booking.setRideId(request.getRideId());
		booking.setVehicleNumber(request.getVehicleNumber());
		booking.setStatus("BOOKED");

		booking = bookingRepository.save(booking);

		// Prepare response DTO
		BookingResponseDto responseDto = new BookingResponseDto();
		responseDto.setBookingId(booking.getId());
		responseDto.setUserId(booking.getUserId());
		responseDto.setRideId(booking.getRideId());
		responseDto.setVehicleNumber(booking.getVehicleNumber());
		responseDto.setStatus(booking.getStatus());

		return responseDto;
	}
}

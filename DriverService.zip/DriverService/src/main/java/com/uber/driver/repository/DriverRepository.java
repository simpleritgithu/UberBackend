package com.uber.driver.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.uber.driver.entities.Driver;

@Repository
public interface DriverRepository extends JpaRepository<Driver, Long> {

	List<Driver> findByVehicletype(String vehicletype); // Get vehicles by type

    Optional<Driver> findByVehiclenumber(String vehiclenumber); // Get driver name by vehicle number
    
    List<Driver> findByStatus(Driver.DriverStatus status);

}

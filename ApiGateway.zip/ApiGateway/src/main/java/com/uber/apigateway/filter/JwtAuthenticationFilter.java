package com.uber.apigateway.filter;

import java.util.Arrays;
import java.util.stream.Collectors;

import org.springframework.http.HttpHeaders;
import org.springframework.http.server.reactive.ServerHttpRequest;
import org.springframework.http.server.reactive.ServerHttpRequestDecorator;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.ReactiveSecurityContextHolder;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.stereotype.Component;
import org.springframework.web.server.ServerWebExchange;
import org.springframework.web.server.WebFilter;
import org.springframework.web.server.WebFilterChain;

import com.uber.apigateway.util.JwtUtil;

import reactor.core.publisher.Mono;

@Component
public class JwtAuthenticationFilter implements WebFilter {

    @Override
    public Mono<Void> filter(ServerWebExchange exchange, WebFilterChain chain) {
        String authorizationHeader = exchange.getRequest()
                .getHeaders()
                .getFirst(HttpHeaders.AUTHORIZATION);

        // Check if the authorization header is present and starts with "Bearer "
        if (authorizationHeader != null && authorizationHeader.startsWith("Bearer ")) {
            String token = authorizationHeader.substring(7);

            try {
                // Validate the token and extract claims
                var claims = JwtUtil.extractClaims(token);

                // Check if the token is expired
                if (!JwtUtil.isTokenExpired(claims)) {
                    // Extract user info from claims (e.g., username and roles)
                    String username = JwtUtil.getUsername(claims);
                    String role = JwtUtil.getRoles(claims);

                    // Build authorities (roles) for the user
                    var authorities = Arrays.stream(new String[]{role})
                            .map(r -> new SimpleGrantedAuthority("ROLE_" + r))
                            .collect(Collectors.toList());

                    // Create an authentication token
                    UsernamePasswordAuthenticationToken authenticationToken = 
                            new UsernamePasswordAuthenticationToken(username, null, authorities);

                    // Use Mono.defer to lazily create the Authentication token and set the security context
                    return Mono.defer(() -> {
                        return chain.filter(exchange.mutate()
                                .request(new ServerHttpRequestDecorator(exchange.getRequest()) {
                                    @Override
                                    public HttpHeaders getHeaders() {
                                        HttpHeaders headers = new HttpHeaders();
                                        headers.putAll(super.getHeaders()); // Copy existing headers
                                        headers.add("loggedInUser", username); // Add custom header
                                        return headers;
                                    }
                                })
                                .build())
                                .contextWrite(ReactiveSecurityContextHolder.withAuthentication(authenticationToken));
                    });
                }
            } catch (Exception e) {
                e.printStackTrace();
                return Mono.error(new RuntimeException("Invalid JWT token"));
            }
        }

        // If no token is provided, proceed without modifications
        return chain.filter(exchange);
    }
}

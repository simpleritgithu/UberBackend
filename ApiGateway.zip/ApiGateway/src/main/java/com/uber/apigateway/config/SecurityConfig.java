package com.uber.apigateway.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.reactive.EnableWebFluxSecurity;
import org.springframework.security.config.web.server.SecurityWebFiltersOrder;
import org.springframework.security.config.web.server.ServerHttpSecurity;
import org.springframework.security.web.server.SecurityWebFilterChain;

import com.uber.apigateway.filter.JwtAuthenticationFilter;



@Configuration
@EnableWebFluxSecurity
public class SecurityConfig {

	@Autowired
    private final JwtAuthenticationFilter jwtAuthenticationFilter;

	@Autowired
    public SecurityConfig(JwtAuthenticationFilter jwtAuthenticationFilter) {
        this.jwtAuthenticationFilter = jwtAuthenticationFilter;
    }

    @Bean
    public SecurityWebFilterChain securityWebFilterChain(ServerHttpSecurity http) {
        return http
            .authorizeExchange(exchanges -> exchanges
            		.pathMatchers( "/payment-service/paymentApi/createUserAccout","/payment-service/paymentApi/test").permitAll()
            		.pathMatchers( "/sports-service/getAllSports","/sports-service/test").permitAll()
           		.pathMatchers( "/user-service/auth/**","/booking-service/test").permitAll()
           		.pathMatchers("/stadium-service/Stadium/getAllStadiums").permitAll()
           		.pathMatchers("/stadium-service/Stadium/testStadium").hasRole("ROLE_user")
            	.pathMatchers("/sport-service/addSport","/sport-service/updateSport","/sport-service/deleteSport/**","/sport-service/getSportById/**").hasRole("ROLE_admin")
            	.pathMatchers("/stadium-service/addStadium","/stadium-service/updateStadium","/stadium-service/deleteStadium/**","/stadium-service/getStadiumById/**").hasRole("ROLE_admin")
                .pathMatchers("/booking-service/**").hasAnyRole("ROLE_user","ROLE_admin")
                .anyExchange().authenticated()              // All other routes require authentication
            )
            .addFilterAt(jwtAuthenticationFilter, SecurityWebFiltersOrder.AUTHENTICATION) // Add JWT filter
            .csrf().disable()  // Disable CSRF for stateless APIs
            .build();
    }
}